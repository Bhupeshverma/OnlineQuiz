<?php

session_start();
$conn =new MySQLi('localhost','root','amit','sherlok');

if(isset($_POST['started'])){
	$start_staus  = $_POST['started'];
	$queryy  = "UPDATE `users` SET `submitted` = 'y' WHERE `users`.`email` = '". $_SESSION['userEmail'] ."'";
	$conn->query($queryy);
	
	$submissionTime = new DateTime();			
		$insertData =  $submissionTime->format('Y-m-d H:i:sP');				
		$saveTime  = "UPDATE `users` SET `dateTime` = '".$insertData."' WHERE `users`.`email` = '".$_SESSION['userEmail']."'";		
		$conn->query($saveTime);				
		echo 'status ok ';
	//echo $_SESSION['userEmail'];
}

if(isset($_POST['locked'])){
	$start_staus  = $_POST['locked'];	
	$queryy  = "UPDATE `users` SET `locked` = 'y' WHERE `users`.`email` = '". $_SESSION['userEmail'] ."'";
	$conn->query($queryy);		
	echo 'status locked ';

	//echo $_SESSION['userEmail'];
}



?>