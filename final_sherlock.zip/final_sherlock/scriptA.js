
      $(function(){
          $("#head-title").typed({
            strings: ["The Starting of the journey  ", "Lets Begin the the Journey  " ,"It may be Entimitating ","But this is gonna be exiting "],
            typeSpeed: 70,
            loop: false,
            startDelay: 100
          });
		  
		  
		  $("#about-text").typed({
            strings: ["Sherlock Holmes is a fictional private detective created by British author Sir Arthur Conan Doyle. Known as a consulting detective ,in the stories, Holmes is known for a proficiency with observation,"],
            typeSpeed: 100,
            loop: true,
            startDelay: 100
          });
		  
      });
	  $('#logo_img').hover(function(e){
		  $('#logo_img').css({
			  transform:'scale(1.1)',
			  transition:'.4s'
			  })
		  },function(e){
			$('#logo_img').css({
			  transform:'scale(1)'
			 })	  
	  });
  
     
     
		var countDownDate = new Date("Feb 16, 2017 17:00:00").getTime();
		var x = setInterval(function() {
			var now = new Date().getTime();
			var distance = countDownDate - now;
			   var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
			 
				if (distance < 0) {
				clearInterval(x);
				document.getElementById("hours").innerHTML = "WELCOME";
			}
			else
			{
						hours = checkTime(hours);
					function checkTime(i) {
						if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
					return i;
				}
			document.getElementById("hours").innerHTML =hours;
			}
			 },1000);
			 
	
        
	
       var countDownDate = new Date("Feb 16, 2017 17:00:00").getTime();
        var x = setInterval(function() {
            var now = new Date().getTime();
            var distance = countDownDate - now;
               var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
             
                 if (distance < 0) {
                clearInterval(x);
                document.getElementById("minutes").innerHTML = "";
            }
            else
            {
            minutes = checkTime(minutes);
                    function checkTime(i) {
                        if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
                    return i;
                }
            document.getElementById("minutes").innerHTML =minutes;
            }
             },1000);
  

     
	
       var countDownDate = new Date("Feb 16, 2017 17:00:00").getTime();
        var x = setInterval(function() {
            var now = new Date().getTime();
            var distance = countDownDate - now;
                var seconds = Math.floor((distance % (1000 * 60)) / 1000);
                 if (distance < 0) {
                clearInterval(x);
                document.getElementById("seconds").innerHTML = "";
            }
            else
            {
            seconds = checkTime(seconds);
                    function checkTime(i) {
                        if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
                    return i;
                }
            document.getElementById("seconds").innerHTML =seconds;
            }
            
             },1000);  

